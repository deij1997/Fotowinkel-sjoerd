package com.paypal.api.payments;

public class ObjectHolder {
	
	public static String refundId;

}
